var class_codigo_agencia =
[
    [ "getCodigoAgencia", "class_codigo_agencia.html#a6cf8cf48bd789fb3d7cf8692cb0908b8", null ],
    [ "setCodigoAgencia", "class_codigo_agencia.html#a0370350f3f62c3d9bc76173627e9e86c", null ]
];