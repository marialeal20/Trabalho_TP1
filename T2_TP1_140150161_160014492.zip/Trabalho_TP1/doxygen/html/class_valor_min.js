var class_valor_min =
[
    [ "getValorMin", "class_valor_min.html#a5708b82e43a8ed3eb0fab0ed18814e04", null ],
    [ "setValorMin", "class_valor_min.html#a6356bb9d485984651795690832026d4d", null ]
];