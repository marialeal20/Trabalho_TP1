var class_t_u_taxa =
[
    [ "run", "class_t_u_taxa.html#a3a785d7d8694c1392b87215981fe67be", null ]
];