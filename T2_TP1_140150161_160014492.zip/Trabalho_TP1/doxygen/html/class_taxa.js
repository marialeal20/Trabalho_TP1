var class_taxa =
[
    [ "getTaxa", "class_taxa.html#a97905b845c3b09e7775f54044e92f28a", null ],
    [ "setTaxa", "class_taxa.html#a1eb527c8ea496932320c574bd41457aa", null ]
];