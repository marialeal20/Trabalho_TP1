var class_horario =
[
    [ "getHorario", "class_horario.html#a543ceb0cbd8444bfe0d6f670df97d676", null ],
    [ "setHorario", "class_horario.html#a40c8660aecd2725dccd830b6248d1772", null ]
];