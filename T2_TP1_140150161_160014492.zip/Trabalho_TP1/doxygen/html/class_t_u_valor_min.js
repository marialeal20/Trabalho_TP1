var class_t_u_valor_min =
[
    [ "run", "class_t_u_valor_min.html#a0a8abffbafbb976a2bb536b105daf901", null ]
];