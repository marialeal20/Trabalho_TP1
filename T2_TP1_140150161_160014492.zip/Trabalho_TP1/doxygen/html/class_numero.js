var class_numero =
[
    [ "getNumero", "class_numero.html#a22b865db8b5c1b366c340a4b4a315bd1", null ],
    [ "setNumero", "class_numero.html#af0abdf8f71a7e556c8942149f0ffb56a", null ]
];