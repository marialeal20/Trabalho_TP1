var class_codigo_aplicacao =
[
    [ "getCodigoAplicacao", "class_codigo_aplicacao.html#aba9ede5df997b1d6e0ce2b4c2739bd0f", null ],
    [ "setCodigoAplicacao", "class_codigo_aplicacao.html#aeaf50973eace6e6d40b54fa4a481cc04", null ]
];