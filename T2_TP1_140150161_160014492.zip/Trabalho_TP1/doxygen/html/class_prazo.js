var class_prazo =
[
    [ "getPrazo", "class_prazo.html#a9b863b76d8082c2b260c708b179e6186", null ],
    [ "setPrazo", "class_prazo.html#aa3334052b8be3af3a2b63415f8b25024", null ]
];