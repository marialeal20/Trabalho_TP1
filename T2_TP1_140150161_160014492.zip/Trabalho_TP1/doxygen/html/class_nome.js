var class_nome =
[
    [ "getNome", "class_nome.html#a1c08f5b9827a1e97a2631196ff99fdef", null ],
    [ "setNome", "class_nome.html#ab1507b81047efb89b50b6be0d33c08e5", null ]
];