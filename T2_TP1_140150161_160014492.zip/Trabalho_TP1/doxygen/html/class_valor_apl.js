var class_valor_apl =
[
    [ "getValorApl", "class_valor_apl.html#a6c0686b23dce4515a58c12d90ebd9533", null ],
    [ "setValorApl", "class_valor_apl.html#a8a051cb0a80a2b62a87b0da72ee1c947", null ]
];