var class_emissor =
[
    [ "getEmissor", "class_emissor.html#a975435c5cb11511949cdd3b362395f35", null ],
    [ "setEmissor", "class_emissor.html#a65bb91077ed6a4cf391a6aab542dd987", null ]
];