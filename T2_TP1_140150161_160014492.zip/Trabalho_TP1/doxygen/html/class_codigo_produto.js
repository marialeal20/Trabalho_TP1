var class_codigo_produto =
[
    [ "getCodigoProduto", "class_codigo_produto.html#ad8825f80ae0d64673ebdb4e510ab6e02", null ],
    [ "setCodigoProduto", "class_codigo_produto.html#ac4b991ab3c991f640a0bfc6c3ce5d81b", null ]
];